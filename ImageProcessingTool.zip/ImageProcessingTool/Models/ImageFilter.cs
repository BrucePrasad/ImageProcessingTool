﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ImageProcessingTool.Models
{
    public class ImageFilter
    {
        public string OriginalImage { get; set; }
        public string GreyscaleImage { get; set; }
    }
}